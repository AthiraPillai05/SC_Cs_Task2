from PIL import Image

# Open encrypted image
image = Image.open("encrypted.png").convert("RGB")

# Get image size
width, height = image.size

# Load pixels
pixels = image.load()

# Same secret key
KEY = 50

# Process every row
for y in range(height):

    # Process two pixels at a time
    for x in range(0, width - 1, 2):

        # Read the swapped pixels
        r2, g2, b2 = pixels[x, y]
        r1, g1, b1 = pixels[x + 1, y]

        # Decrypt them
        r1 = (r1 - KEY) % 256
        g1 = (g1 - KEY) % 256
        b1 = (b1 - KEY) % 256

        r2 = (r2 - KEY) % 256
        g2 = (g2 - KEY) % 256
        b2 = (b2 - KEY) % 256

        # Restore original positions
        pixels[x, y] = (r1, g1, b1)
        pixels[x + 1, y] = (r2, g2, b2)

# Save decrypted image
image.save("decrypted.png")

print("Image decrypted successfully!")