from PIL import Image

# Open the original image
image = Image.open("sample.png").convert("RGB")

# Get image size
width, height = image.size

# Load pixels
pixels = image.load()

# Secret key
KEY = 50

# Process every row
for y in range(height):

    # Process two pixels at a time
    for x in range(0, width - 1, 2):

        # Read neighboring pixels
        r1, g1, b1 = pixels[x, y]
        r2, g2, b2 = pixels[x + 1, y]

        # Encrypt first pixel
        r1 = (r1 + KEY) % 256
        g1 = (g1 + KEY) % 256
        b1 = (b1 + KEY) % 256

        # Encrypt second pixel
        r2 = (r2 + KEY) % 256
        g2 = (g2 + KEY) % 256
        b2 = (b2 + KEY) % 256

        # Swap the encrypted pixels
        pixels[x, y] = (r2, g2, b2)
        pixels[x + 1, y] = (r1, g1, b1)

# Save encrypted image
image.save("encrypted.png")

print("Image encrypted successfully!")