import tkinter as tk
from tkinter import filedialog, messagebox
from PIL import Image
import os

# Variable to store the selected image
selected_image = ""

# -------------------- SELECT IMAGE --------------------
def select_image():
    global selected_image

    selected_image = filedialog.askopenfilename(
        title="Select an Image",
        filetypes=[("Image Files", "*.png *.jpg *.jpeg *.bmp")]
    )

    if selected_image:
        file_label.config(text=os.path.basename(selected_image))
        status_label.config(text="")


# -------------------- ENCRYPT --------------------
def encrypt_image():
    global selected_image

    if not selected_image:
        messagebox.showerror("Error", "Please select an image first!")
        return

    try:
        KEY = int(key_entry.get())
    except ValueError:
        messagebox.showerror("Error", "Key must be a number!")
        return

    image = Image.open(selected_image).convert("RGB")

    width, height = image.size
    pixels = image.load()

    # Encrypt + Swap
    for y in range(height):
        for x in range(0, width - 1, 2):

            # Read neighboring pixels
            r1, g1, b1 = pixels[x, y]
            r2, g2, b2 = pixels[x + 1, y]

            # Encrypt first pixel
            r1 = (r1 + KEY) % 256
            g1 = (g1 + KEY) % 256
            b1 = (b1 + KEY) % 256

            # Encrypt second pixel
            r2 = (r2 + KEY) % 256
            g2 = (g2 + KEY) % 256
            b2 = (b2 + KEY) % 256

            # Swap pixels
            pixels[x, y] = (r2, g2, b2)
            pixels[x + 1, y] = (r1, g1, b1)

    save_path = os.path.join(
        os.path.dirname(selected_image),
        "encrypted.png"
    )

    image.save(save_path)

    # Automatically select encrypted image
    selected_image = save_path
    file_label.config(text=os.path.basename(selected_image))

    status_label.config(text="Image Encrypted Successfully!")

    messagebox.showinfo(
        "Success",
        "Encrypted image saved successfully!"
    )


# -------------------- DECRYPT --------------------
def decrypt_image():
    global selected_image

    if not selected_image:
        messagebox.showerror("Error", "Please select an image first!")
        return

    try:
        KEY = int(key_entry.get())
    except ValueError:
        messagebox.showerror("Error", "Key must be a number!")
        return

    image = Image.open(selected_image).convert("RGB")

    width, height = image.size
    pixels = image.load()

    # Swap Back + Decrypt
    for y in range(height):
        for x in range(0, width - 1, 2):

            # Read swapped pixels
            r2, g2, b2 = pixels[x, y]
            r1, g1, b1 = pixels[x + 1, y]

            # Decrypt
            r1 = (r1 - KEY) % 256
            g1 = (g1 - KEY) % 256
            b1 = (b1 - KEY) % 256

            r2 = (r2 - KEY) % 256
            g2 = (g2 - KEY) % 256
            b2 = (b2 - KEY) % 256

            # Restore original positions
            pixels[x, y] = (r1, g1, b1)
            pixels[x + 1, y] = (r2, g2, b2)

    save_path = os.path.join(
        os.path.dirname(selected_image),
        "decrypted.png"
    )

    image.save(save_path)

    # Automatically select decrypted image
    selected_image = save_path
    file_label.config(text=os.path.basename(selected_image))

    status_label.config(text="Image Decrypted Successfully!")

    messagebox.showinfo(
        "Success",
        "Decrypted image saved successfully!"
    )


# -------------------- GUI --------------------
root = tk.Tk()

root.title("Image Encryption Tool")
root.geometry("500x420")
root.resizable(False, False)

# Title
title = tk.Label(
    root,
    text="IMAGE ENCRYPTION TOOL",
    font=("Arial", 16, "bold")
)

title.pack(pady=15)

# Browse Button
browse_button = tk.Button(
    root,
    text="Select Image",
    width=20,
    command=select_image
)

browse_button.pack(pady=10)

# File Label
file_label = tk.Label(
    root,
    text="No Image Selected",
    fg="blue"
)

file_label.pack()

# Key Label
key_label = tk.Label(
    root,
    text="Enter Encryption Key:"
)

key_label.pack(pady=(20, 5))

# Key Entry
key_entry = tk.Entry(
    root,
    width=20,
    justify="center"
)

key_entry.insert(0, "50")

key_entry.pack()

# Button Frame
button_frame = tk.Frame(root)
button_frame.pack(pady=15)

# Encrypt Button
encrypt_button = tk.Button(
    button_frame,
    text="Encrypt",
    width=15,
    command=encrypt_image
)

encrypt_button.pack(side="left", padx=10)

# Decrypt Button
decrypt_button = tk.Button(
    button_frame,
    text="Decrypt",
    width=15,
    command=decrypt_image
)

decrypt_button.pack(side="left", padx=10)

# Status Label
status_label = tk.Label(
    root,
    text="",
    fg="green",
    font=("Arial", 10, "bold")
)

status_label.pack(pady=10)

# Run GUI
root.mainloop()